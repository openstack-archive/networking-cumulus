============
Installation
============

At the command line::

    $ pip install networking-cumulus

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv networking-cumulus
    $ pip install networking-cumulus
